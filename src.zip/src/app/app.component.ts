import { Component, ViewChild } from '@angular/core';
import { Nav, Platform,ModalController  } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
//import {LoginPage} from '../pages/login/login';
//import {SignupPage} from '../pages/signup/signup';

import { firebaseConfig } from './credentials';
//import { GeoMap} from '../pages/geo-map/geo-map';
//import {GoogleMap} from '../pages/g-map/g-map';
import { SplashPage } from '../pages/splash/splash';
import firebase from 'firebase';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFirestore, AngularFirestoreDocument } from 'angularfire2/firestore';
import { User } from '../interface/dataModel';
import { Observable } from 'rxjs/Observable';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = HomePage;
  public uid: string;
  name: any;
  pages: Array<{ title: string, component: any }>;

  private userDoc: AngularFirestoreDocument<User>;
  user: Observable<User>;

  constructor(public platform: Platform,
      public statusBar: StatusBar,
      splashScreen: SplashScreen,
      modalCtrl: ModalController,
      public af: AngularFireAuth,
      public db: AngularFirestore) {

   // this.initializeApp();
    //firebase.initializeApp(firebaseConfig);
    // used for an example of ngFor and navigation
    this.pages = [
        { title: 'Home', component: HomePage },
        { title: 'Location selection', component: 'LocationSelectionPage' },
        { title:'Order History',component:'OrderHistoryPage'},
        { title: 'Profile', component: 'ProfilePage' },      
        { title: 'Restaurant List', component: 'RestaurantListPage' },
        { title: 'Search', component: 'SearchPage'},
        {title:'Favorite',component:'FavoritePage'},
        {title:'Facebook', component:'FacebookPage'}
    ];
    
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      //this.splashScreen.hide();
      statusBar.styleDefault();
 
            let splash = modalCtrl.create(SplashPage);
            splash.present();
    });
     
    }

      ngOnInit() {
          this.uid = localStorage.getItem('uid');
         // console.log('uid = ' + this.uid);
          if (this.uid != null) {
              this.userDoc = this.db.doc<User>('/userProfile/' + this.uid);
              //this.user =
              this.userDoc.valueChanges().map(data => {
                  console.log('data = ' + data);
              });
              console.log('User = ' + this.user);
              /*.valueChanges().subscribe((res: any) => {
                  this.name = res.name;
                  //console.log('Name = ' + this.name);
                  //this.imageUrl = res.image != '' && res.image != null ? res.image : "assets/img/profile.jpg";
              })*/
              this.rootPage = 'RestaurantListPage';
          } else {
              this.rootPage = 'LoginPage';
          }
      }

  openPage(page) {
   
    this.nav.setRoot(page.component);
  }
}
