import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MyApp } from './app.component';
//import { HomePage } from '../pages/home/home';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ElasticHeaderModule } from 'ionic2-elastic-Header/dist';
//import { HideHeaderDirective } from '../directives/hide-header/hide-header';
import { AuthProvider } from '../providers/auth/auth';
import { CartServiceProvider } from '../providers/cart-service/cart-service';
import { Ionic2RatingModule } from 'ionic2-rating';
import { Geolocation } from '@ionic-native/geolocation';
import { HttpModule } from '@angular/http';
import { SplashPage } from '../pages/splash/splash';
import { BarRatingModule } from 'ngx-bar-rating'

import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireStorageModule } from 'angularfire2/storage';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireDatabase } from 'angularfire2/database';
import { firebaseConfig } from './credentials';

import { AngularFireDatabaseModule } from 'angularfire2/database';
import { NativeGeocoder } from '@ionic-native/native-geocoder';
import { Facebook } from '@ionic-native/facebook';
import { SelectSearchableModule } from 'ionic-select-searchable';
@NgModule({ 
  declarations: [
    MyApp,
    
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    ElasticHeaderModule,
    SelectSearchableModule,
   // Ionic2RatingModule,
    HttpModule,
    //BrowserAnimationsModule,
      BarRatingModule,
      AngularFireModule.initializeApp(firebaseConfig),
      AngularFirestoreModule, // imports firebase/firestore, only needed for database features
      AngularFireAuthModule, // imports firebase/auth, only needed for auth features,
      AngularFireStorageModule, // imports firebase/storage only needed for storage features
      AngularFireAuthModule,
      AngularFireDatabaseModule

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    
  
  ],
  providers:[
    Geolocation,
    Facebook,
    NativeGeocoder,
    SplashScreen,
    {provide:ErrorHandler,useClass:IonicErrorHandler},
    AuthProvider,
      StatusBar,
      CartServiceProvider
  ]
 
})
export class AppModule {}
