export const firebaseConfig = {
    apiKey: "AIzaSyDSURPi4gBF9BEp2_3UPv_3jys-o7okSJU",
    authDomain: "foodmantra-64679.firebaseapp.com",
    databaseURL: "https://foodmantra-64679.firebaseio.com",
    projectId: "foodmantra-64679",
    storageBucket: "foodmantra-64679.appspot.com",
    messagingSenderId: "53488200323"
}


export const dbcollection =
    {
        restaurantcollection: 'restaurant',
        menucategory: 'restaurntCategory',
        menucollection: 'menuitem',
        reviewcollection:'restaurantreview',
        favoritecollection: 'favoriterestaurant',
        addresscollection:'deliveryaddress',
        cartcollection:'cart'
    };
