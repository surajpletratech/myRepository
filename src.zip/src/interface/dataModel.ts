export interface RestaurantModel {
    key?: any;
    name: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    phone: string;
    email: string;
    cost: string;
    description: string;
    longitude: string;
    latitude: string;
}

export interface MenuItem {
    Id: string;
    Restaurantkey: string;
    menucategory: string;
    name: string;
    description: string;
    price: string;
    ingredient: string;
    rating?: number;

}

export interface RestarauntCategoryModel {
    key: any;
    category: Array<string>;
}

export interface CartItem {
    itemId: String,
    extraOptions: Array<any>,
    price: {
        name: "",
        value: Number,
        currency: ''
    },
    name: '',
    thumb: String,
    itemQunatity: number,
    restaurantId: string
}

export interface User {
    uid: string,
    name: string,
    email: string,
    mobile: string
}

export interface orederHistory{
    restaurant_name:string;
    total:number;
    order_time:string;
}

export interface RestaurantReviewModel{
    Id:string;
    Restaurantkey:string;
    RestaurantRating:string;
    RestaurantReview:string;
} 

export interface Favorite {
    restaurantName:string,
    restaurantPhone:string,
    restaurantCity:string,
    restaurantMinOrder:string,
    restaurantCost:string,
    uid:string,
    email:string,
    Id:string
}

export interface addressModel{
    Id:string, 
    city:string,
    area:string,
    street:string,
    landmark:string,
    postcode:number,
    userEmail:string
}

export interface cartModel{
    restaurantName:string,
    orderDate:string,
    paymentMode:string,
    cart:any;
    uid:string,
    total:string,
    Id:string;
}
