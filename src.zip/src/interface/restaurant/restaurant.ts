export interface Restaurant {
    name: string;
    location: string;
    minPrice: number;
    rating:number;
    city:string;
    state:string;
    country:string;
}