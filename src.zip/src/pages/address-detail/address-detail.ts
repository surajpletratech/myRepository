import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {addressModel} from '../../interface/dataModel';
//import {AngularFirestore,AngularFirestoreCollection} from 'angularfire2/firestore';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { dbcollection } from '../../app/credentials';
import { AlertController } from 'ionic-angular';

/**
 * Generated class for the AddressDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-address-detail',
  templateUrl: 'address-detail.html',
})
export class AddressDetailPage {
  private addressCollection:  AngularFirestoreCollection<addressModel>;
  public items: Observable<any[]>;
  public addressData:Array<any>;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, public db: AngularFirestore,public alertCtrl:AlertController) {
    this.addressCollection = db.collection<addressModel>(dbcollection.addresscollection);
      this.items = this.addressCollection.valueChanges();
       this.items.subscribe( data =>{
         this.addressData = data;
        console.log('Address Detail',this.addressData);
       })  
  
        /* this.items = this.addressCollection.snapshotChanges().map(actions => {
            return actions.map(a => {
                const data = a.payload.doc.data() as addressModel;
                const Id = a.payload.doc.id
                return { Id, ...data };
            });
            });
        */
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddressDetailPage');
  }

  saveAddress(City:string,Area:string,Street:string,Landmark:string,Postcode:number){
    let data:addressModel ={
      Id: this.db.createId(),
      city:City,
      area:Area,
      street:Street,
      landmark:Landmark,
      postcode:Postcode,
      userEmail:localStorage.getItem('email')
    }

    console.log('data',data);
    console.log('data ID:-'+data.Id);

    //this.addressCollection.add(data);
    this.addressCollection.doc(data.Id).set(data);
    let alert = this.alertCtrl.create({
            subTitle: 'New address added successfully',
            buttons: [ {
              text: 'Ok',
              role: 'cancel',
              handler: () => {
                this.navCtrl.setRoot('ProfilePage');
              }
            }
          ]
          });
          alert.present();
    }
  }

