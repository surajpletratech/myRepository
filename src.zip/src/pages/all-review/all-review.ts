import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Restaurant } from '../../interface/restaurant/restaurant';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { RestaurantReviewModel } from '../../interface/dataModel';
import { dbcollection } from '../../app/credentials';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

/**
 * Generated class for the AllReviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-all-review',
  templateUrl: 'all-review.html',
})
export class AllReviewPage {
    item: any;
  private reviewCollection : AngularFirestoreCollection<RestaurantReviewModel>;
  public items:Observable<any[]>;
  public RestaurantData:Observable<RestaurantReviewModel>;
  restaurantkey:string;
  public reviewId:string;
  constructor(public navCtrl: NavController, public navParams: NavParams,private db:AngularFirestore ) 
  {
        this.reviewCollection =  db.collection<RestaurantReviewModel>(dbcollection.reviewcollection);
        this.items = this.reviewCollection.snapshotChanges().map(actions => {
          return actions.map(a => {
              const data = a.payload.doc.data() as RestaurantReviewModel;
              const Id = a.payload.doc.id

              return { Id, ...data };
          });
      })
      
      
      this.reviewId = navParams.get("Data");
      console.log(this.reviewId);
      console.log('data'+this.items);
      console.log('review Id:-',this.reviewId);
      this.restaurantkey ='CMn4GwrRtKDTRxWvnzG9';
      console.log('restaurant ID'+this.restaurantkey);
      this.reviewCollection.doc(this.restaurantkey).ref.get().then(function(doc) {
        if (doc.exists) {
            console.log('Document is exist!');
            console.log("Document data:", doc.data());
        } else {
            console.log("No such document!");
        }
      }).catch(function(error) {
          console.log("Error getting document:", error);
      });
  }
  ionViewDidLoad() {
       
    const size$ = new BehaviorSubject<string>(null);
      
    this.item = size$.switchMap(size =>
     this.db.collection(dbcollection.reviewcollection, ref => ref.where('Restaurantkey', '==', size)).valueChanges() );
     size$.next(this.restaurantkey);
     /*
      this.restaurantkey = 'CMn4GwrRtKDTRxWvnzG9';
      let items = this.db.doc<any>('restaurantreview/'+this.restaurantkey);
      this.RestaurantData = items.valueChanges();
      console.log('data of Restuarant review'+this.RestaurantData);
      console.log('ionViewDidLoad AllReviewPage');
     */
    }
}
