import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AngularFirestore,AngularFirestoreCollection} from 'angularfire2/firestore';
import {dbcollection} from '../../app/credentials'
import {addressModel, cartModel} from '../../interface/dataModel';
import { Observable } from 'rxjs/Observable';
import { AlertController } from 'ionic-angular';
import { messaging } from 'firebase';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@IonicPage()
@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html',
})
export class CheckoutPage {
  public pay:any;
  public username:string;
  public usermobile:string;
  public cartItem:any[] = [];
  private addressCollection:AngularFirestoreCollection<addressModel>;
  public items: Observable<any[]>;
  public addressDetail:Array<any>;
  public GrandTotal:string;
  public orderDate:string;
  private cartCollection:AngularFirestoreCollection<cartModel>;
  private restauranName:string;
  constructor(public navCtrl: NavController,
     public navParams: NavParams,
     public db:AngularFirestore,
     public alrtCtl:AlertController) {
     this.pay =
     this.addressCollection = db.collection<addressModel>(dbcollection.addresscollection);
     this.cartCollection = db.collection<cartModel>(dbcollection.cartcollection)
     this.items = this.addressCollection.valueChanges();
     this.items.subscribe(data => {
        this.addressDetail = data;
        console.log('addressdata',this.addressDetail);
     })
     this.username = localStorage.getItem('userName');
     this.usermobile = localStorage.getItem('userMobile');
     console.log(this.username);
     console.log(this.usermobile);
     this.cartItem = this.navParams.get('cartItem');
     this.GrandTotal = this.navParams.get('GrandTotal');
     this.restauranName = this.navParams.get('RestaurntName');
     console.log('Restaurant Name',this.restauranName);
     console.log('cart data',this.cartItem); 
     console.log('GrandTotal',this.GrandTotal);
     //console.log('item name',this.cartItem.)
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CheckoutPage');
  }

 payment(paymentMethod:any){
   console.log('Payment Mode:',paymentMethod);   
   localStorage.setItem('paymentMode',paymentMethod);
   let d = new Date();
   var dd = d.getDate();
   var mm = d.getMonth() + 1;
   var yy = d.getFullYear();
   var hh   =  d.getHours(); // => 9
   var min      =  d.getMinutes(); // =>  30
   var sec       =  d.getSeconds();
  var date = dd + '/' + mm + '/' + yy + ' ' + hh + ':' + min; 
   console.log('order date',date);

   localStorage.setItem('deliveredCartItem',JSON.stringify(this.cartItem));
   localStorage.setItem('grandTotal',this.GrandTotal);
   localStorage.setItem('orderDate',date);
   let alert = this.alrtCtl.create({
      title:'Order Confirmation',
      subTitle:'Thank you for your order!',
      cssClass:'alertCustomCss',
      buttons:[
        {
          text:'Ok',
          handler:() =>{
          this.navCtrl.setRoot('RestaurantListPage'); 
          console.log('Ok Clicked');
         }
        }
      ]
   });
   alert.present();
   let Data:cartModel = {
    restaurantName:this.restauranName,
    orderDate:date,
    paymentMode:paymentMethod,
    cart:this.cartItem,
    uid:localStorage.getItem('uid'),
    total:this.GrandTotal,
    Id:this.db.createId()
  }
     
      console.log('Firebase Data:', Data);
      this.cartCollection.doc('Id').set(Data);
    
  }

}
