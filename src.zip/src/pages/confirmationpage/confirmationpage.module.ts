import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConfirmationpagePage } from './confirmationpage';

@NgModule({
  declarations: [
    ConfirmationpagePage,
  ],
  imports: [
    IonicPageModule.forChild(ConfirmationpagePage),
  ],
})
export class ConfirmationpagePageModule {}
