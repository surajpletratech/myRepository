import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CookiePolicyPage } from './cookie-policy';

@NgModule({
  declarations: [
    CookiePolicyPage,
  ],
  imports: [
    IonicPageModule.forChild(CookiePolicyPage),
  ],
})
export class CookiePolicyPageModule {}
