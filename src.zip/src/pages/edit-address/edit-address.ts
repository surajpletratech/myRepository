import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {addressModel} from '../../interface/dataModel';
import {AngularFirestore,AngularFirestoreCollection} from 'angularfire2/firestore';
import {dbcollection} from '../../app/credentials';
import firebase from 'firebase';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from '@firebase/util';
import {AlertController} from 'ionic-angular';
@IonicPage()
@Component({
  selector: 'page-edit-address',
  templateUrl: 'edit-address.html',
})
export class EditAddressPage {
  public addressCollection:  AngularFirestoreCollection<addressModel>;
  addressDetail:addressModel;
  public Id:string; 
  public address:Observable<any>;
  public updateAdd:firebase.database.Reference
  public items:Observable<addressModel>
  constructor(public navCtrl: NavController,
     public navParams: NavParams,
     public db:AngularFirestore,
     public dbFire:AngularFireDatabase,
     public alertCtrl:AlertController) {
   let dataRef = dbFire.list('/addresscollection');
    this.addressDetail = this.navParams.get('addressData');
    let id = this.addressDetail.Id;
   // var ref = db.collection('addresscollection').doc(this.Id).update(da)
    this.addressCollection = db.collection<addressModel>(dbcollection.addresscollection);
   /* let items = this.addressCollection.snapshotChanges().map(actions => {
      return actions.map(a => {
          const data = a.payload.doc.data() as addressModel;
          const Id = a.payload.doc.id
          return { Id, ...data };
      });
  });*/
    console.log(this.addressDetail);
    //this.updateAdd = firebase.database().ref('addresscollection');
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditAddressPage');
  }

  updateAddress(ID:string,City:string,Area:string,Street:string,LandMark:string,Postcode:string){
     console.log('In update method');
     console.log('Id'+ID+'City'+City+'Area'+Area+'Street'+Street+'LandMark'+LandMark);
     this.Id = ID;
    let Data = {
      city:City,
      area:Area,
      street:Street,
      landmark:LandMark,
      postcode:Postcode
     }
      console.log(Data);
      console.log(this.Id);
      
     
      this.addressCollection.doc(this.Id).update(Data);
      
      
     /* 
     this.addressCollection.ref.doc().update
     let items = this.db.doc<any>('addresscollection/' + this.Id);
      console.log(items);
      let address = items.valueChanges();
      items.set(Data);
      */
      /*let dataRef = this.dbFire.list('/addresscollection');
      dataRef.update(this.Id,Data);
     */ 
      //this.updateAdd.child(this.Id).update(Data);
      
       this.addressCollection = this.db.collection(dbcollection.addresscollection);
       let alert = this.alertCtrl.create({
        title: 'Address Updated Succesfully',
        
        buttons: [{
          text: 'Ok',
          
          handler: () => {
            console.log('Cancel clicked');
            this.navCtrl.setRoot('ProfilePage');
          }
        }]
      });
      alert.present();
}
     //  this.addressCollection.doc(this.Id).update(Data);
     // console.log(this.addressCollection);
     
     //let data = this.addressCollection.ref.where("Id", "==", "this.Id").get();
     //console.log(data);
     //var refe = this.db.collection('addresscollection');
    
     //   refe.update()
    // this.addressCollection.
    

  
    /*this.addressCollection.set(Data).catch(error =>{
       console.log(error)
     }); let items = this.db.doc<any>('deliveryaddress/' + this.Id);
     items.set(Data).catch(error =>
      {
        console.log(error);
      }
    )*/
    }
