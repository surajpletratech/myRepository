import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { User } from '../../interface/dataModel';
import { Observable } from 'rxjs/Observable';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { AngularFireAuth } from 'angularfire2/auth';
import { AlertController } from 'ionic-angular';
/**
 * Generated class for the EditProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-edit-profile',
  templateUrl: 'edit-profile.html',
})
export class EditProfilePage {
  public user:Observable<User>;
  public userName:string;
  public mobileNumber:string;
  public emailId:string;
  public currentUserId:string;
  public userData:User;
  public addressData:Array<any>;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public db: AngularFirestore,
    public af: AngularFireAuth,private alertCtrl: AlertController) 
    {
          this.addressData = this.navParams.get('addressdata');
          this.userData = this.navParams.get('Data');
          console.log('User Data:-',this.userData);
          console.log('Address Data:-',this.addressData);
         /* this.userName=this.userData.name;
          this.mobileNumber = this.userData.mobile;
          this.emailId = this.userData.email
          this.currentUserId = this.userData.uid;*/
    }

  ionViewDidLoad() {
          console.log('ionViewDidLoad EditProfilePage');
          let items = this.db.doc<any>('userprofile/' + this.af.auth.currentUser.uid);
          this.user = items.valueChanges();
  }
  
  updateProfile(userName:string,emailId:string,mobileNumber:string){
            const path = `users/${this.currentUserId}`;
            let data = {
              name: userName,
              email: emailId,
              mobile:mobileNumber
    }
            let items = this.db.doc<any>('userprofile/' + this.af.auth.currentUser.uid);
            this.user = items.valueChanges();
            console.log('Data:-  '+userName+ ' ' +''+emailId+' '+mobileNumber); 
          
            items.set(data).catch(error=>{
              console.log(error);
            });

              let alert = this.alertCtrl.create({
                title: 'Profile Updated Succesfully',
                
                buttons: [{
                  text: 'Ok',
                  
                  handler: () => {
                    console.log('Cancel clicked');
                    this.navCtrl.setRoot('ProfilePage');
                  }
                }]
              });
              alert.present();
    }
    
  } 

