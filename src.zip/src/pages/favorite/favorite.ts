import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Favorite} from '../../interface/dataModel';
import { Observable } from '@firebase/util';
import { dbcollection } from '../../app/credentials';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
declare var something: boolean;
@IonicPage()
@Component({
  selector: 'page-favorite',
  templateUrl: 'favorite.html',
})
export class FavoritePage {
  public NoFavoriteItem:boolean;
   item:any;
   items:Array<any>;
   Email:string;
   uid:string;
   private favoriteCollection: AngularFirestoreCollection<Favorite>; 
   
   constructor(public navCtrl: NavController, public navParams: NavParams, public db:AngularFirestore) {
    this.favoriteCollection = db.collection<Favorite>(dbcollection.favoritecollection);
    this.uid = localStorage.getItem('uid'); 
    
    
  }

  ionViewDidLoad() {
    console.log(this.NoFavoriteItem);
    this.favoriteCollection.valueChanges().subscribe(data =>
      {
        this.items = data;
        console.log('data is',this.items);
      
        this.items.forEach(data => {
          if(data.uid == this.uid){
            console.log(data.uid);
            this.NoFavoriteItem = false;
            console.log('Boolean Condition',this.NoFavoriteItem)
         }

       })
      }
    );
   
    
    console.log('ionViewDidLoad FavoritePage');
    
    console.log('User ID:-'+this.uid);
    const size$ = new BehaviorSubject<string>(null);
      
    this.item = size$.switchMap(size =>
    this.db.collection(dbcollection.favoritecollection, ref => ref.where('uid', '==', size)).valueChanges() );
    size$.next(this.uid);
  
    console.log('User Data:-',this.item);
  }

  deleteIcon(deleteId:string){
    this.favoriteCollection.ref.where("Id","==" ,deleteId).get().then(query =>{
          query.forEach((data) => {
            data.ref.delete().then( ()=> {
              console.log('doc deleted');
            })
          })
    });
   }
  
Delete(itemKey:string) {
    //console.log('in delete:-' +itemKey);
    this.NoFavoriteItem = true; 
    console.log(this.NoFavoriteItem);
    this.favoriteCollection.ref.where("Id", "==", itemKey)
.get()
.then(querySnapshot => {
querySnapshot.forEach((record) => {
record.ref.delete().then(() => {
  console.log("Document successfully deleted!");
}).catch(function(error) {
  console.error("Error removing document: ", error);
});
});
})
.catch(function(error) {
console.log("Error getting documents: ", error);
});
}

deleteAll(UID:string){
  this.favoriteCollection.ref.where("Id", "==" , UID).get().then(query =>{
    console.log(query);
  })
}

}
