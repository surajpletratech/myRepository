import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import {  ViewChild, ElementRef } from '@angular/core';
import { NativeGeocoder, NativeGeocoderReverseResult, NativeGeocoderForwardResult } from '@ionic-native/native-geocoder';
import { PopoverController } from 'ionic-angular';
import {RestaurantModel} from '../../interface/dataModel';
import {AngularFirestore,AngularFirestoreCollection} from 'angularfire2/firestore';
import { Observable } from '@firebase/util';
import { dbcollection } from '../../app/credentials';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
declare var google: any;
@IonicPage()

@Component({
  selector: 'page-location-selection',
  templateUrl: 'location-selection.html',
})
export class LocationSelectionPage implements OnInit {
  
  restaurantLocation:any;
  public item: any;
  public latitude:any;
  public longitude:any;
  error:string;
  address:string;
  public sortedData:Array<any>;
  private restaurantCollection:AngularFirestoreCollection<RestaurantModel>;
  public items:Observable<any[]>;
  public restaurantData:Array<any>;
  public uid:string;
  public restau:any;
  
  public restaurant:Observable<any>
  @ViewChild('map') mapRef: ElementRef;
  map : any;
  google: any = null;
  positionOption ={ timeout:10000, enableHighAccuracy:false};
  
  constructor(public navCtrl: NavController, 
    public navParams: NavParams,
    private geolocation: Geolocation,
    private nativeGeocoder: NativeGeocoder,
    public popoverCtrl: PopoverController,
    public db:AngularFirestore) {
               this.restaurantCollection = db.collection<RestaurantModel>(dbcollection.restaurantcollection);
               //this.restaurantCollection.valueChanges().subscribe(Data => {
                 
               //    this.restaurantData = Data;
                //   console.log('Restaurant Data:-',this.restaurantData)
                //    data.forEach(restaurant=>{
                  
                 //      console.log('ResturantData:-',restaurant);
                 //    })       
              /*    this.restaurantData.forEach(data =>{
                    console.log('Record name',data.name)
                    if(data.name === 'Bhoj'){
                      console.log('In Condition');
                   //   this.sortedData.push('one');
                      console.log('Sorted Data',this.sortedData);
                    }
                  })  
                })
         */
               this.uid = localStorage.getItem('uid');
               console.log('user id',this.uid) 
               
               let data = this.restaurantCollection.snapshotChanges().map(actions => {
                return actions.map(a => {
                    const data = a.payload.doc.data() as RestaurantModel;
                    const Id = a.payload.doc.id
                    return { Id, ...data };
                });
            });
            
              
              this.getLoc();           
    }
  presentPopover(myEvent) {
  
  }
  ngOnInit(): void {
      }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LocationSelectionPage');
   
    
    this.showMap();
    const size$ = new BehaviorSubject<string>(null);
      this.item = size$.switchMap(size =>
        this.db.collection(dbcollection.restaurantcollection, ref => ref.where('latitude', '==', '18.4477802').where('longitude', '==', '73.90657689999999')).valueChanges() );
        size$.next(this.uid);
        console.log('restaurant record by location',this.item);
  }

  ionViewDidEnter(){
     const size$ = new BehaviorSubject<string>(null);
      this.restau= size$.switchMap(size => this.db.collection(dbcollection.restaurantcollection,ref=> ref.where('latitude','==', '18.4477802').where('logitude','==','73.90657689999999')).valueChanges());
      size$.next(this.uid);
      console.log('restaurant data',this.restau);
    }
   public getLoc():void{
    this.geolocation.getCurrentPosition().then( pos =>{
          this.latitude = pos.coords.latitude;
          this.longitude = pos.coords.longitude;
          localStorage.setItem('lng',this.longitude);
          localStorage.setItem('lat',this.latitude); 
          console.log('latitude',this.latitude);
          console.log('logitude',this.longitude); 
        }).catch(err => console.log(err));
      
        this.latitude = localStorage.getItem('lng');
        this.longitude = localStorage.getItem('lat');    
        console.log(this.latitude);
        console.log(this.longitude)
    
        let watch = this.geolocation.watchPosition();
        watch.subscribe((data) => {
             this.latitude = data.coords.latitude;
             this.longitude = data.coords.longitude;
            });   
          this.nativeGeocoder.reverseGeocode(this.latitude,this.longitude).then((result: NativeGeocoderReverseResult) => {
          console.log('IN reverseGeocode',this);
          console.log('adress is'+JSON.stringify(result));
        this.address = JSON.stringify(result);
      })
      .catch((error: any) => {
      this.error = error;
      console.log('Error Is:-'+this.error);
      });
      const size$ = new BehaviorSubject<string>(null);
      this.item = size$.switchMap(size =>
        this.db.collection(dbcollection.restaurantcollection, ref => ref.where('latitude', '==', '18.4477802').where('longitude', '==', '73.90657689999999')).valueChanges() );
        size$.next(this.uid);
        console.log('restaurant record by location',this.item);


      } 

showMap(){
  //Location - lat lng
  const location = new google.maps.LatLng(18.461077,73.925133);

  //Map options
  const options = {
    center: location,
    zoom: 10
  }
  
this.map = new google.maps.Map(this.mapRef.nativeElement,options);
this.addMarker(location, this.map);
}

addMarker(position, map){
  return new google.maps.Marker({
    position,
    map
  });
}

addAddress(){
  this.navCtrl.push('AddressDetailPage');
}

getRestaurant(){
  this.restaurantData.forEach(data =>
  {
    console.log(data);
  })
}
}
