import { Component } from '@angular/core';
import { IonicPage, NavController, LoadingController, Platform, AlertController, Events } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthProvider } from '../../providers/auth/auth';

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
    tagHide: boolean = true;
    valForm: FormGroup;
    constructor(public navCtrl: NavController,
        public fb: FormBuilder,
        public loadingCtrl: LoadingController,
        public alertCtrl: AlertController,
        public platform: Platform,
        public events: Events,
        public authProvider: AuthProvider) {
        this.valForm = fb.group({
            'email': ['', Validators.compose([Validators.required, Validators.pattern("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$")])],
            'password': ['', Validators.required]
        });
    }


  OnLogin($ev, value: any) {
      $ev.preventDefault();
      for (let c in this.valForm.controls) {
          this.valForm.controls[c].markAsTouched();
      }
      if (this.valForm.valid) {
          this.authProvider.loginUser(value.email, value.password)
              .then((success) => {
                
                  localStorage.setItem('uid', success.uid);
                  localStorage.setItem('email',value.email);
                  localStorage.setItem('mobile',value.mobile);
                  console.log()
                  this.navCtrl.setRoot('RestaurantListPage');
              })
              .catch((error) => {
                  this.showAlert(error.message);
              })
      }
  }

  showAlert(message) {
      let alert = this.alertCtrl.create({
          subTitle: message,
          buttons: ['OK']
      });
      alert.present();
  }

  Register() {
      this.navCtrl.setRoot("SignupPage");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  ForgetPassword(){
      this.navCtrl.push("ForgetPasswordPage");
  }

  termsPage():void{
      this.navCtrl.push('TermsOfServicePage');      
  }

  contentPage():void{
      this.navCtrl.push('ContentPolicyPage');
  }

  privacyPage():void{
      this.navCtrl.push('PrivacyPolicyPage');
  }
}
