import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {NonvegDetailPage} from '../nonveg-detail/nonveg-detail';
import {ViewCartPage} from '../view-cart/view-cart';
/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {
  public currentNumber:number = 0;
  public Total:number = null;
  public cost:number= null;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  } 

  ionViewDidLoad() {
    console.log('ionViewDidLoad MenuPage');
  }
 
  nonvegDetail(){
    console.log('in detail page');
    this.navCtrl.push('NonvegDetailPage');
  }

  increment():void {
    this.currentNumber++;
    this.Total = this.currentNumber * 250; 
  }
  decrement():void {
    this.currentNumber--;
    this.Total = this.Total - 250;
  }
  
  addressDetail():void{
    this.navCtrl.push('AddressDetailPage');
  }

}
