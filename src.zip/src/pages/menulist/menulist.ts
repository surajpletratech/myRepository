import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {MenuPage} from '../menu/menu';
import {VegPage} from '../veg/veg';
//import {Food} from '../../interface/foodlist/foodlist';
import { MenuItem } from '../../interface/dataModel';
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/observable/combineLatest';
import { dbcollection } from '../../app/credentials';

import { CartItem } from '../../interface/dataModel';
import { CartServiceProvider } from '../../providers/cart-service/cart-service';

@IonicPage()
@Component({
  selector: 'page-menulist',
  templateUrl: 'menulist.html',
})
export class MenulistPage {

    sortdata:any;   
    restaurantName: string;
    restaurantkey: string;
    //item: Observable<MenuItem[]> = null;
    item:any;
    items: Array<MenuItem[]> = null;

    noOfItems: number = 0;



    constructor(public navCtrl: NavController,
        public navParams: NavParams,
        private db: AngularFirestore,
        private cs: CartServiceProvider
   ) {

        this.restaurantkey = navParams.get("id"); //"oQcWGmBxAK72SX3IkwFa"; //

        if (this.restaurantkey == undefined) {
            this.navCtrl.push("RestaurantListPage")
        }

        this.restaurantName = navParams.get("name");
        console.log('restaurantkey = ' + this.restaurantkey);
       
        
 }

 gotoMenuList(){
    console.log('menulist');
    this.navCtrl.push('MenuPage');
  }

  gotoVegMenu(){
    this.navCtrl.push('VegPage');
  }

  gotoMithaiMenu(){
    this.navCtrl.push('MithaiPage');
  }
  initializeItems() {
    this.sortdata = this.item;
}

  gotoMenu(){
      this.navCtrl.push('NonvegDetailPage');
  }
  gotoChineseMenu(){
    this.navCtrl.push('ChineseFoodPage');
  }
  
  gotoCartPage(){
    this.navCtrl.push('CartPage',{'restaurantName':this.restaurantName});
  }

  addToCart(item: any) {
      console.log('Add to cart');
      this.noOfItems = this.noOfItems + 1;
      console.log('no = ' + this.noOfItems);

      let menucartitem: CartItem = {
          itemId: item.Id,
          extraOptions: null,
          itemQunatity: 1,
          name: item.name,
          price: {
              name: "",
              value:item.price,
              currency: ''
          },
          thumb: null,
          restaurantId: this.restaurantkey
      }
      console.log('Item price'+menucartitem.price.value);
      this.cs.OnSave(menucartitem);
       
    }

  removeFromCart(item: any) {
      if (this.noOfItems > 0)
          this.noOfItems = this.noOfItems - 1;
  }

  getItems(ev: any) {
     this.initializeItems();
      let val = ev.target.value;
      console.log(val);
      if (val && val.trim() != '') {
          this.item = this.item.filter((data) => {
              return (data.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
          })
      }
  }

  ionViewWillEnter() {
      let cart: Array<any> = JSON.parse(localStorage.getItem('Cart'));
      this.noOfItems = cart != null ? cart.length : null;
  }

  ionViewDidLoad() {

      const size$ = new BehaviorSubject<string>(null);
      this.item = size$.switchMap(size =>
          this.db.collection(dbcollection.menucollection, ref => ref.where('Restaurantkey', '==', size)).valueChanges()
      );
   
       this.item = size$.switchMap(size => 
       this.db.collection(dbcollection.menucollection,ref => ref.where('Restaurantkey','==',size)).valueChanges());
       size$.next(this.restaurantkey);
       console.log('MenuListPage'+this.item);
    }

}
