import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {AllReviewPage} from '../all-review/all-review';
import {AddreviewPage} from '../addreview/addreview';
import {MenuDetailPage} from '../menu-detail/menu-detail';
import { AlertController } from 'ionic-angular';
/**
 * Generated class for the NewPoonabakeryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-new-poonabakery',
  templateUrl: 'new-poonabakery.html',
})
export class NewPoonabakeryPage {

  constructor(public navCtrl: NavController, public navParams: NavParams,public alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewPoonabakeryPage');
  }

  showAllReview(){
    this.navCtrl.push('AllReviewPage');
  }
  addReview(){
    this.navCtrl.push('AddreviewPage');
  }

  gotoMenu() {
    this.navCtrl.push('MenulistPage');
  }

  rating(){
    const alert = this.alertCtrl.create({
      title: 'Rate your speech:',
      subTitle: 'bleu',
      cssClass: 'alertstar',
      enableBackdropDismiss:false,
      buttons: [
           { text: '1'},// data => { this.resolveRec(1);}},
           { text: '2'},// handler:},// data => { this.resolveRec(2);}},
           { text: '3'},// handler:}, // data => { this.resolveRec(3);}},
           { text: '4'},// handler: //data => { this.resolveRec(4);}},
           { text: '5'},// handler: //data => { this.resolveRec(5);}}
      ]
 });
 alert.present();
  }
} 
