import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import{AddressDetailPage} from '../address-detail/address-detail';
import {FormGroup,FormBuilder,Validators} from '@angular/forms';
/**
 * Generated class for the NonvegDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-nonveg-detail',
  templateUrl: 'nonveg-detail.html',
})
export class NonvegDetailPage {
  
  CookingForm:FormGroup;
  public currentNumber:number = 0;
  public Total:number = null;
  public cost:number= null;
  information: any[];
  public instruction:string;
  constructor(public navCtrl: NavController, public navParams: NavParams,private http: Http,public formbuilder:FormBuilder) {
    this.cost= 250;
    
    this.CookingForm = formbuilder.group({
      instruction:['Spicy',Validators.required]
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NonvegDetailPage');
  }

  increment():void {
    this.currentNumber++;
    this.Total = this.currentNumber * 250; 
  }
  decrement ():void {
    this.currentNumber--;
    this.Total = this.Total - 250;
  }
  toggleSection(i) {
    this.information[i].open = !this.information[i].open;
  }
 
  toggleItem(i, j) {
    this.information[i].children[j].open = !this.information[i].children[j].open;
  }

  gotoMenu(){
    this.navCtrl.push('MenulistPage');
  }

  gotoAddress(){
    this.navCtrl.push('AddressDetailPage');
  }
  CartPage(){
    this.navCtrl.push('CartPage');
  }
     
}
