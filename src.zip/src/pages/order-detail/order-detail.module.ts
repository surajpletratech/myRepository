import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OrderDetailPage } from './order-detail';
import {BarRatingModule} from 'ngx-bar-rating';
@NgModule({
  declarations: [
    OrderDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(OrderDetailPage),
    BarRatingModule
  ],
})
export class OrderDetailPageModule {}
