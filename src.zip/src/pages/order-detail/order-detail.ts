import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { dbcollection } from '../../app/credentials';

/**
 * Generated class for the OrderDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-order-detail',
  templateUrl: 'order-detail.html',
})
export class OrderDetailPage {
 // item: Observable<{}>;
  review:FormGroup;
  public paymentMode:string;
  public orderDate:string;
  public total:string;
  public orderDetail:any;
  public orderData:Array<any>;
  constructor(public navCtrl: NavController, public navParams: NavParams,public formBuilder:FormBuilder) {
    this.review=formBuilder.group({
      addReview: ['review',Validators.required]
    });
 
   
    this.orderData  = this.navParams.get('Data');
    this.orderDetail = this.orderData;
    console.log('Ordered Data',this.orderDetail);
    this.paymentMode = localStorage.getItem('paymentMode');
  //  console.log((localStorage.getItem('paymentMode')));
  //  console.log((localStorage.getItem('Cart')));
  //  this.orderDate = localStorage.getItem('orderDate');
  //  console.log(this.orderDate);
 //   this.total = localStorage.getItem('total');
 }
  ionViewDidLoad() {
    console.log('ionViewDidLoad OrderDetailPage');
    const size$ = new BehaviorSubject<string>(null);
      
   // this.item = size$.switchMap(size =>
   //           this.db.collection(dbcollection.cartcollection, ref => ref.where('uid', '==', size)).valueChanges() );
   //            size$.next(this.uid);

   // console.log('Switch Map',this.item);

  }

}
