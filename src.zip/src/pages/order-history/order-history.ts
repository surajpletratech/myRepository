import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { orederHistory } from '../../interface/dataModel';
import {AngularFirestore,AngularFirestoreCollection} from 'angularfire2/firestore';
import {cartModel} from '../../interface/dataModel';
import { dbcollection } from '../../app/credentials';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Rx';

@IonicPage()
@Component({
  selector: 'page-order-history',
  templateUrl: 'order-history.html',
})
export class OrderHistoryPage {

  public orderHistory:boolean=false;
  item: any;
  public cartCollection:AngularFirestoreCollection<cartModel>;
  public total: string;
  public orderDate: string;
  public paymentMode: string;
  restaurant_name: any;
  public cartData:Array<any>;
  public uid:string;
  public items: Observable<any[]>;
   

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public db:AngularFirestore) {
    this.paymentMode = localStorage.getItem('paymentMode');
    this.uid = localStorage.getItem('uid');
    this.orderDate = localStorage.getItem('orderDate');
    this.total = localStorage.getItem('total');
    this.cartCollection = db.collection<cartModel>(dbcollection.cartcollection);
  
   this.uid = localStorage.getItem('uid');
   console.log('User Id:-'+this.uid);
   // console.log('Cart Data',this.cartData);
  // this.getData();
  }

  getData(){
    this.cartData.forEach(data=>{
      console.log('In Method')
      console.log(data)      
    });
  }

  ionViewDidLoad() {
        
    this.cartCollection.valueChanges().forEach(data=>{
      this.cartData = data;
      console.log('Data',this.cartData);
    })
     console.log('data:-',this.cartData);
        console.log('Order History Page');
        const size$ = new BehaviorSubject<string>(null);
        this.item = size$.switchMap(size =>
        this.db.collection(dbcollection.cartcollection, ref => ref.where('uid', '==', size)).valueChanges() );
        size$.next(this.uid);
        console.log('user record',this.item);
  }

  deleteOrder(itemKey:string){
    
    console.log('in delete:-' +itemKey);
    
    this.cartCollection.ref.where("Id", "==", itemKey)
        .get()
         .then(querySnapshot => {
            querySnapshot.forEach((record) => {
                record.ref.delete().then(() => {
                console.log("Document successfully deleted!");
                }).catch(function(error) {
                console.error("Error removing document: ", error);
             });
          });
        }).catch(function(error) {
     console.log("Error getting documents: ", error);
    });
    let data = localStorage.getItem('name');
    let uid = localStorage.getItem('uid');
 }
 orderDetail(data:any){
   console.log('in order detail',data);
   //console.log(id,' ', restaurantName,' ',orderDate,' ',total,' ',name );
   this.navCtrl.push('OrderDetailPage',{
      Data:data});
 }
}
