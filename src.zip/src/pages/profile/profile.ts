import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { AngularFireDatabase,/*AngularFireObject,*/AngularFireList } from 'angularfire2/database';
import { AngularFireAuth } from 'angularfire2/auth';
import { AuthProvider } from '../../providers/auth/auth';
import { User ,addressModel} from '../../interface/dataModel';
import { Observable } from 'rxjs/Observable';
import { dbcollection } from '../../app/credentials';

/**
 * Generated class for the ProfilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage implements OnInit {
  slideOneForm: FormGroup;
  public UserName:string = '';
  public Email:string;
  public Password:string;
  public Mobile: string;
  public user: Observable<User> = null;
  userData:User;
  public deliveryData:Array<any>;
  public items: Observable<any[]>;
  public addressData:Array<any>;
  private addressCollection:  AngularFirestoreCollection<addressModel>;

  constructor(public navCtrl: NavController,
      public navParams: NavParams,  
      public formBuilder: FormBuilder,
      public af: AngularFireAuth,
      public db: AngularFirestore,
      public ap: AuthProvider,
      public adb: AngularFireDatabase,) 
      {
        this.addressCollection = db.collection<addressModel>(dbcollection.addresscollection);
        this.items = this.addressCollection.valueChanges();
        this.items.subscribe( data =>{
            this.addressData = data;
            console.log('Address Detail',this.addressData);
        })  
    //  let data = this.navParams.get('addressdata');
    //  this.deliveryData = data;
    //  console.log('Address Detail',this.deliveryData);
     
      if (this.af.auth.currentUser) {
          //this.user = this.ap.getUser(this.af.auth.currentUser.uid);
          //console.log('Profile user = ' + this.user.name);
          
      } else {

          this.navCtrl.setRoot('LoginPage');
      }

      this.slideOneForm = this.formBuilder.group({
          UserName: ['', Validators.required],
          Email: [this.af.auth.currentUser.email, Validators.required],
          Password: ['', Validators.required],
          Mobile: ['', Validators.required]
      });

  }

  ngOnInit() {
      let items = this.db.doc<any>('userprofile/' + this.af.auth.currentUser.uid);
      this.user = items.valueChanges();
      this.user.subscribe(data =>
       {
           this.userData = data;
           let name = data.name;
           let mobile = data.mobile;
           localStorage.setItem('userName',name);
           localStorage.setItem('userMobile',mobile);
           console.log(this.userData);
       }
    )
  }

  ionViewWillEnter() {
      //console.log('User profile = ' + this.user);
      //this.UserName = this.user.name;


  }

  ionViewDidLoad() {
      console.log('ionViewDidLoad ProfilePage');

  }
  
  OrderHistoryPage(){
    this.navCtrl.push("OrderHistoryPage");
  }

  Favorite(){
    this.navCtrl.push('FavoritePage');
  }

  editProfile(){
      let userData = this.user;
      this.navCtrl.push('EditProfilePage',{Data:this.userData});
  }

  deleteAddress(itemKey:string) {
    console.log('in delete:-' +itemKey);
    
    this.addressCollection.ref.where("Id", "==", itemKey )
        .get()
         .then(querySnapshot => {
            querySnapshot.forEach((record) => {
                record.ref.delete().then(() => {
                console.log("Document successfully deleted!");
                }).catch(function(error) {
                console.error("Error removing document: ", error);
             });
          });
        }).catch(function(error) {
     console.log("Error getting documents: ", error);
    });
}
  AddNewAddress(){
    this.navCtrl.push('AddressDetailPage');
  }

  editAddress(data:any){
      this.navCtrl.push('EditAddressPage',{addressData:data});
  }
}
