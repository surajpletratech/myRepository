import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Restaurant } from '../../interface/restaurant/restaurant';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { RestaurantModel } from '../../interface/dataModel';
import { dbcollection } from '../../app/credentials';
import {Favorite} from '../../interface/dataModel';
import { isBlank } from 'ionic-angular/util/util';
import { AlertController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-restaurant-list',
  templateUrl: 'restaurant-list.html',
})
export class RestaurantListPage {

   Email:string;
   emailExist:boolean;
   uid:string;
   restaurant:Restaurant=null;
   public restaurantName:string;
   EmailOfUser:boolean;
   public userEmail:string;
   public userData:boolean;
   favoriteRestaurant:Array<any>;
   private restaurntCollection: AngularFirestoreCollection<RestaurantModel>;
   private favoriteCollection:  AngularFirestoreCollection<Favorite>;
   public items: Observable<any[]>;
   
   constructor(public navCtrl: NavController,
      public navParams: NavParams,
      public db: AngularFirestore,
      public alertCtrl:AlertController,
      private toastCtrl: ToastController){
      this.restaurntCollection = db.collection<RestaurantModel>(dbcollection.restaurantcollection);
      this.favoriteCollection = db.collection<Favorite>(dbcollection.favoritecollection);    
      this.items = this.restaurntCollection.snapshotChanges().map(actions => {
          return actions.map(a => {
              const data = a.payload.doc.data() as RestaurantModel;
              const Id = a.payload.doc.id
              return { Id, ...data };
          });
      });

     this.favoriteCollection.valueChanges().subscribe(data =>{
         this.favoriteRestaurant = data;    
     });
  }

  ionViewDidLoad() {
          this.Email = localStorage.getItem('email');
          this.uid = localStorage.getItem('uid');
        
        /*console.log('Email is',this.Email);
          console.log('User Id', this.uid);*/
          if(this.Email === null)
          {
             this.emailExist = false;
             console.log(this.emailExist);
             // console.log('email is not present');
          }
          else{
              this.emailExist = true;
              console.log(this.emailExist);
           // console.log('email is present');
          }
          console.log('ionViewDidLoad RestaurantListPage');
  }

  gotoMenu(key: any, rName: string) {
      console.log('Key = ' + key);
      this.navCtrl.push('MenulistPage', {id: key, name: rName});
  }
  addResturant(){
    this.navCtrl.push('addRestaurantPage');
  }

 gotoProfile(key: any){
   console.log('restaurantProfileKey'+key);
   this.navCtrl.push('RestaurantProfilePage',{id:key});
 }


 Favorite(Name:string,Phone:string,City:string,minOrder:string,Cost:string){
  console.log('In Favorite method');
  this.restaurantName = Name;
  this.userEmail = localStorage.getItem('email');
   this.favoriteRestaurant.forEach(data=>{
     
      if(data.restaurantName === this.restaurantName && data.email === localStorage.getItem('email')){
         this.EmailOfUser =true;
      }
   });
  let userFavoriteName :boolean =  this.favoriteRestaurant.some(x => 
    x.restaurantName === this.restaurantName
  );
  let userEmail :boolean =  this.favoriteRestaurant.some(x => 
    x.email ===  localStorage.getItem('email')
  );
 
  this.uid = localStorage.getItem('uid');
  
  console.log('restaurant Name:-'+this.restaurantName);
  console.log('user id'+this.uid);
   if(this.Email === null){
          let alert = this.alertCtrl.create({
            title: 'Login!',
            subTitle: 'Please login ',
            buttons: [ {
              text: 'Cancel',
              role: 'cancel',
              handler: () => {
                console.log('Cancel Clicked');
              }
            },
            {
              text: 'login',
              handler: () => {
                console.log('login Clicked');
                this.navCtrl.setRoot('LoginPage');
              }
            }
          ]
          });
          alert.present();
          
    }else if(this.EmailOfUser){
      let toast =this.toastCtrl.create({
        message:'Already Added as Favorite',
        duration: 1000,
        position:'bottom'
      });

      toast.onDidDismiss(()=>{
        console.log('Dismissed Toast');
      });

      toast.present();
    }
    else {
        let data:Favorite = {
            restaurantName:Name,
            restaurantPhone:Phone,
            restaurantCity:City,
            restaurantMinOrder:minOrder,
            restaurantCost:Cost,
            uid:this.uid,
            email:this.Email,
            Id:this.db.createId()
          }
          console.log('Favorite restaurant data:-' , data);
          this.favoriteCollection.add(data);

          let toast = this.toastCtrl.create({
            message: 'Added successfully',
            duration: 3000,
            position: 'bottom'
          });
        
          toast.onDidDismiss(() => {
            console.log('Dismissed toast');
          });
        
          toast.present();
        }  
  }
}

