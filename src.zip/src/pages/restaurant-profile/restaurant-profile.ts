import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Restaurant } from '../../interface/restaurant/restaurant';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { RestaurantModel,RestaurantReviewModel} from '../../interface/dataModel';
import { dbcollection } from '../../app/credentials';
import { map } from '@firebase/util';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import { AlertController } from 'ionic-angular';
@IonicPage()
@Component({
  selector: 'page-restaurant-profile',
  templateUrl: 'restaurant-profile.html',
})
export class RestaurantProfilePage {
  restaurant: Observable<any[]>;
 
  review:string;
  rating:string;
  private restaurntCollection: AngularFirestoreCollection<RestaurantModel>;
  private reviewCollection:AngularFirestoreCollection<RestaurantReviewModel>;
  public RestaurantData:Observable<RestaurantModel>;
  username: string;
  restaurantkey: string;
  constructor(public navCtrl: NavController, public navParams: NavParams,public db:AngularFirestore, public alertCtrl:AlertController)
   {
      this.restaurantkey = navParams.get("id");
    
      this.restaurntCollection = db.collection<RestaurantModel>(dbcollection.restaurantcollection);
      this.reviewCollection = db.collection<RestaurantReviewModel>(dbcollection.reviewcollection)
      
      console.log(this.reviewCollection);
      console.log('got restaurant key:'+this.restaurantkey);
 
      this.reviewCollection.ref.where("name","==","Mirchi").get().then(data =>{
          let qName = data;
          console.log('Name'+qName);   
      });

      this.restaurntCollection.doc(this.restaurantkey).ref.get().then(function(doc) {
        if (doc.exists) {
            console.log("Document data:", doc.data());
        } else {
            console.log("No such document!");
        }
      }).catch(function(error) {
          console.log("Error getting document:", error);
      });
  }
  ionViewDidLoad() {
      let items = this.db.doc<any>('restaurant/'+this.restaurantkey);
      this.RestaurantData = items.valueChanges();
      console.log('data'+this.RestaurantData);
  }

  addReview(Review:string,Rating:string){
       let key = this.restaurantkey;
       console.log('Id of currentrestaurant'+key);
       this.review = Review;
       this.rating = Rating;
       console.log("your review"+this.review); 
       console.log("Your Rating:-"+this.rating); 
       
       let data:RestaurantReviewModel = {
         Id:this.db.createId(),
         Restaurantkey:this.restaurantkey,
         RestaurantReview:this.review,
         RestaurantRating:this.rating
       }
       let d = data;
       console.log('interface data'+d.Id);
       this.reviewCollection.add(data);

       let alert = this.alertCtrl.create({
        title: 'Review',
        
        buttons: [ {
          text: 'Review Saved Succesfully',
          handler: () => {
            console.log('login Clicked');
            
            this.navCtrl.push('AllReviewPage');
          }
        }
      ]
      });
      alert.present();
  }
  gotoAllReview(Id:string){
    console.log('in all review');
     console.log('Restaurant Data:-',Id)
     this.navCtrl.push('AllReviewPage',{RestoData:Id});
  }

  All(Id:string){
    let key =Id;
    console.log('In all method');

  }

  AddReview(id:string){
    console.log('In add review page');
    this.navCtrl.push('AddreviewPage',{Id:id});
  }
}
