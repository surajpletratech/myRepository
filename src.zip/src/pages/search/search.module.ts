import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SearchPage } from './search';
import { SelectSearchableModule } from 'ionic-select-searchable';
@NgModule({
  declarations: [
    SearchPage,
  ],
  imports: [
    IonicPageModule.forChild(SearchPage),
    SelectSearchableModule
  ],
})
export class SearchPageModule {}
