import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SelectSearchable } from 'ionic-select-searchable';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import {Observable} from 'rxjs/Observable';
import { dbcollection } from '../../app/credentials';
import { RestaurantModel } from '../../interface/dataModel' 


class Port {
  public id: number;
  public name: string;
}

class Listassiagn {
  public city:string;
  public cost:string;
  public description:string;
  public email:string;
  public minorder:string;
  public name: string;
  public phone:string;  
  public state:string;
  public zip:string;
}
@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
  ports: Port[];
  port: Port;
  public items: Observable<any[]>;
  private restaurntCollection: AngularFirestoreCollection<RestaurantModel>;
  list:Array<any>;
  list2:Array<any>;

  
  constructor(public navCtrl: NavController, public db:AngularFirestore,public navParams: NavParams) {
    this.restaurntCollection = this.db.collection<RestaurantModel>(dbcollection.restaurantcollection); 
    this.restaurntCollection.valueChanges().subscribe(data =>{
        this.list = data;
        this.list2=this.list
        console.log('Search data',this.list);

    })
    this.ports = [
      { id: 1, name: 'Mirchi' },
     
      { id: 2, name: 'Spices' },
      { id: 3, name: 'Bhoj' },
      {id:4,name:'Mantra'},
      {id:5,name:'channa Masala'},
      {id:6,name:'Veggi Pizza'},
      {id:7,name:'chicken curry'},
      {id:8,name:'Alu Gobi'},
      {id:9,name:'Dal Makhni'},
  ];

  this.generateTopics();
  }
  portChange(event: { component: SelectSearchable, value: any }) {
    console.log('port:', event.value);

    
}
  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchPage');
  }
  generateTopics() {
     this.list
  }

  getTopics(ev: any) {
    this.generateTopics();
    let serVal = ev.target.value;
    if (serVal && serVal.trim() != '') {
      this.list = this.list.filter((topic) => {
        return topic.toString().toLowerCase().indexOf(serVal.toLowerCase()) > -1;
       // return (topic.to.toLowerCase().indexOf(serVal.toLowerCase() > -1));
      })
    }
  }
}
