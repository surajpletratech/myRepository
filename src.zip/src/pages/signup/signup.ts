import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, LoadingController, Platform, AlertController, Events } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { AuthProvider } from '../../providers/auth/auth';
//import { GooglePlus } from '@ionic-native/google-plus';
//import { TwitterConnect } from '@ionic-native/twitter-connect';
//import { Facebook } from '@ionic-native/facebook';

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage implements OnInit {

    registration: FormGroup;

    constructor(public navCtrl: NavController,
        public events: Events,
        public fb: FormBuilder,
        //public facebook: Facebook,
        //public googlePlus: GooglePlus,
        public loadingCtrl: LoadingController,
        public alertCtrl: AlertController,
        //public twitter: TwitterConnect,
        public platform: Platform,
        public authProvider: AuthProvider) {
    }

    onSubmit() {
        this.authProvider.signupUser(this.registration.value.email,
            this.registration.value.password,
            this.registration.value.name,
            this.registration.value.mobileNo).then(user => {
                localStorage.setItem('uid', user.uid);
                localStorage.setItem('email',user.email);
                localStorage.setItem('mobile',user.mobile);
                localStorage.setItem('name',user.name);
                console.log(user.mobile);
                this.navCtrl.setRoot('RestaurantListPage');
            })
            .catch((error) => {
                console.log("Firebase failure: " + JSON.stringify(error));
                this.showAlert(error.message);
            });;
    }

    showAlert(message) {
        let alert = this.alertCtrl.create({
            subTitle: message,
            buttons: ['OK']
        });
        alert.present();
    }

    ngOnInit(): any {
        this.buildForm();
    }

    buildForm(): void {
        this.registration = new FormGroup({
            'name': new FormControl('', Validators.required),
            'mobileNo': new FormControl('', Validators.required),
            'email': new FormControl('', [Validators.required, Validators.pattern("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$")]),
            'password': new FormControl('', [Validators.required, Validators.minLength(4), Validators.maxLength(24)])
        });
    }

    doFbLogin(): void {
      
    }

    googleLogin(): void {

    }

    navLogin(): void {
        this.navCtrl.setRoot('LoginPage');
    }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }
  termsPage():void{
      this.navCtrl.push('TermsOfServicePage');
  }
  privacyPage():void{
      this.navCtrl.push('PrivacyPolicyPage');   
  }
  contentPage():void{
      this.navCtrl.push('ContentPolicyPage');
  }
}
