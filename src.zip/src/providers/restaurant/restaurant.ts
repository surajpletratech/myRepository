import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Restaurant } from '../../interface/restaurant/restaurant';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { RestaurantModel } from '../../interface/dataModel';
import { dbcollection } from '../../app/credentials';
/*
  Generated class for the RestaurantProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class RestaurantProvider {

    constructor(public http: HttpClient,
        public db: AngularFirestore) {
    console.log('Hello RestaurantProvider Provider');
    }

    getRestaurantInfo(key: string): any {
        let rest = this.db.doc<any>(dbcollection.restaurantcollection + "/" + key);
        return rest.valueChanges();

    }

}
